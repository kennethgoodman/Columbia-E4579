class AbstractFilter:
    def filter_ids(self, content_ids, seed, starting_point):
        pass
