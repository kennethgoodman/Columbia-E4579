class AbstractController:
    def get_content_ids(self, user_id, limit, offset, seed, starting_point):
        pass
