class AbstractRanker:
    def rank_ids(self, limit, probabilities, seed, starting_point):
        pass
