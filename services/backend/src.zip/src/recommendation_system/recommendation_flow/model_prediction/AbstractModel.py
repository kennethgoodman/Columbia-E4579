class AbstractModel:
    def predict_probabilities(self, content_ids, user_id, seed=None, **kwargs):
        pass
